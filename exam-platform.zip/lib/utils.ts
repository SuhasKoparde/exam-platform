import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: Date) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(date)
}

export function calculateScore(answers: Record<string, string>, correctAnswers: Record<string, string>) {
  let score = 0
  const total = Object.keys(correctAnswers).length

  for (const [questionId, answer] of Object.entries(answers)) {
    if (correctAnswers[questionId] === answer) {
      score++
    }
  }

  return {
    score,
    total,
    percentage: Math.round((score / total) * 100),
  }
}
