import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Medal } from "lucide-react"

export default async function LeaderboardPage() {
  const supabase = createClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    return null
  }

  // Get all users with their average scores
  const { data: weeklyLeaderboard } = await supabase.rpc("get_weekly_leaderboard").limit(20)

  const { data: monthlyLeaderboard } = await supabase.rpc("get_monthly_leaderboard").limit(20)

  const { data: allTimeLeaderboard } = await supabase.rpc("get_all_time_leaderboard").limit(20)

  // Find current user's rank
  const findUserRank = (leaderboard: any[]) => {
    if (!leaderboard) return null
    const userRank = leaderboard.findIndex((item) => item.user_id === session.user.id)
    return userRank !== -1
      ? {
          rank: userRank + 1,
          ...leaderboard[userRank],
        }
      : null
  }

  const userWeeklyRank = findUserRank(weeklyLeaderboard || [])
  const userMonthlyRank = findUserRank(monthlyLeaderboard || [])
  const userAllTimeRank = findUserRank(allTimeLeaderboard || [])

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Leaderboard</h2>
        <p className="text-muted-foreground">See how you rank against other students</p>
      </div>

      {(userWeeklyRank || userMonthlyRank || userAllTimeRank) && (
        <Card>
          <CardHeader>
            <CardTitle>Your Rankings</CardTitle>
            <CardDescription>Your current position on the leaderboards</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="flex flex-col items-center p-4 bg-muted rounded-md">
                <div className="text-sm font-medium text-muted-foreground">Weekly</div>
                <div className="text-3xl font-bold">{userWeeklyRank ? `#${userWeeklyRank.rank}` : "N/A"}</div>
                {userWeeklyRank && (
                  <div className="text-sm text-muted-foreground">{userWeeklyRank.average_score.toFixed(1)}%</div>
                )}
              </div>
              <div className="flex flex-col items-center p-4 bg-muted rounded-md">
                <div className="text-sm font-medium text-muted-foreground">Monthly</div>
                <div className="text-3xl font-bold">{userMonthlyRank ? `#${userMonthlyRank.rank}` : "N/A"}</div>
                {userMonthlyRank && (
                  <div className="text-sm text-muted-foreground">{userMonthlyRank.average_score.toFixed(1)}%</div>
                )}
              </div>
              <div className="flex flex-col items-center p-4 bg-muted rounded-md">
                <div className="text-sm font-medium text-muted-foreground">All Time</div>
                <div className="text-3xl font-bold">{userAllTimeRank ? `#${userAllTimeRank.rank}` : "N/A"}</div>
                {userAllTimeRank && (
                  <div className="text-sm text-muted-foreground">{userAllTimeRank.average_score.toFixed(1)}%</div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="weekly" className="space-y-4">
        <TabsList>
          <TabsTrigger value="weekly">Weekly</TabsTrigger>
          <TabsTrigger value="monthly">Monthly</TabsTrigger>
          <TabsTrigger value="all-time">All Time</TabsTrigger>
        </TabsList>

        <TabsContent value="weekly">
          <Card>
            <CardHeader>
              <CardTitle>Weekly Leaderboard</CardTitle>
              <CardDescription>Top performers for this week</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {weeklyLeaderboard?.map((item, index) => (
                  <div
                    key={item.user_id}
                    className={`flex items-center gap-4 p-3 rounded-md ${
                      item.user_id === session.user.id ? "bg-primary/10" : index < 3 ? "bg-muted" : ""
                    }`}
                  >
                    <div className="flex items-center justify-center w-8 h-8">
                      {index < 3 ? (
                        <Medal
                          className={`h-6 w-6 ${
                            index === 0 ? "text-yellow-500" : index === 1 ? "text-gray-400" : "text-amber-700"
                          }`}
                        />
                      ) : (
                        <span className="text-lg font-bold">{index + 1}</span>
                      )}
                    </div>
                    <Avatar>
                      <AvatarFallback>
                        {item.name
                          ?.split(" ")
                          .map((n: string) => n[0])
                          .join("") || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="font-medium">{item.name}</div>
                      <div className="text-sm text-muted-foreground">{item.tests_taken} tests taken</div>
                    </div>
                    <div className="text-xl font-bold">{item.average_score.toFixed(1)}%</div>
                  </div>
                ))}
                {(!weeklyLeaderboard || weeklyLeaderboard.length === 0) && (
                  <div className="text-center py-8 text-muted-foreground">No data available for this week</div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monthly">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Leaderboard</CardTitle>
              <CardDescription>Top performers for this month</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {monthlyLeaderboard?.map((item, index) => (
                  <div
                    key={item.user_id}
                    className={`flex items-center gap-4 p-3 rounded-md ${
                      item.user_id === session.user.id ? "bg-primary/10" : index < 3 ? "bg-muted" : ""
                    }`}
                  >
                    <div className="flex items-center justify-center w-8 h-8">
                      {index < 3 ? (
                        <Medal
                          className={`h-6 w-6 ${
                            index === 0 ? "text-yellow-500" : index === 1 ? "text-gray-400" : "text-amber-700"
                          }`}
                        />
                      ) : (
                        <span className="text-lg font-bold">{index + 1}</span>
                      )}
                    </div>
                    <Avatar>
                      <AvatarFallback>
                        {item.name
                          ?.split(" ")
                          .map((n: string) => n[0])
                          .join("") || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="font-medium">{item.name}</div>
                      <div className="text-sm text-muted-foreground">{item.tests_taken} tests taken</div>
                    </div>
                    <div className="text-xl font-bold">{item.average_score.toFixed(1)}%</div>
                  </div>
                ))}
                {(!monthlyLeaderboard || monthlyLeaderboard.length === 0) && (
                  <div className="text-center py-8 text-muted-foreground">No data available for this month</div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="all-time">
          <Card>
            <CardHeader>
              <CardTitle>All Time Leaderboard</CardTitle>
              <CardDescription>Top performers of all time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {allTimeLeaderboard?.map((item, index) => (
                  <div
                    key={item.user_id}
                    className={`flex items-center gap-4 p-3 rounded-md ${
                      item.user_id === session.user.id ? "bg-primary/10" : index < 3 ? "bg-muted" : ""
                    }`}
                  >
                    <div className="flex items-center justify-center w-8 h-8">
                      {index < 3 ? (
                        <Medal
                          className={`h-6 w-6 ${
                            index === 0 ? "text-yellow-500" : index === 1 ? "text-gray-400" : "text-amber-700"
                          }`}
                        />
                      ) : (
                        <span className="text-lg font-bold">{index + 1}</span>
                      )}
                    </div>
                    <Avatar>
                      <AvatarFallback>
                        {item.name
                          ?.split(" ")
                          .map((n: string) => n[0])
                          .join("") || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="font-medium">{item.name}</div>
                      <div className="text-sm text-muted-foreground">{item.tests_taken} tests taken</div>
                    </div>
                    <div className="text-xl font-bold">{item.average_score.toFixed(1)}%</div>
                  </div>
                ))}
                {(!allTimeLeaderboard || allTimeLeaderboard.length === 0) && (
                  <div className="text-center py-8 text-muted-foreground">No data available</div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
