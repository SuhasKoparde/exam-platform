"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { CalendarIcon, Loader2, Plus, Trash } from "lucide-react"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn, formatDate } from "@/lib/utils"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function EditTestPage({ params }: { params: { id: string } }) {
  const [test, setTest] = useState<any>(null)
  const [questions, setQuestions] = useState<any[]>([])
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [duration, setDuration] = useState("30")
  const [isWeekend, setIsWeekend] = useState(false)
  const [isPublished, setIsPublished] = useState(false)
  const [loading, setLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)

  // New question form
  const [newQuestion, setNewQuestion] = useState("")
  const [options, setOptions] = useState(["", "", "", ""])
  const [correctAnswer, setCorrectAnswer] = useState("")
  const [subject, setSubject] = useState("")

  const router = useRouter()
  const supabase = createClient()
  const { toast } = useToast()

  useEffect(() => {
    const fetchTest = async () => {
      try {
        const { data: testData, error: testError } = await supabase
          .from("tests")
          .select("*")
          .eq("id", params.id)
          .single()

        if (testError) throw testError

        setTest(testData)
        setTitle(testData.title)
        setDescription(testData.description)
        setDate(new Date(testData.scheduled_date))
        setDuration(testData.duration.toString())
        setIsWeekend(testData.is_weekend)
        setIsPublished(testData.is_published)

        const { data: questionsData, error: questionsError } = await supabase
          .from("questions")
          .select("*")
          .eq("test_id", params.id)
          .order("order", { ascending: true })

        if (questionsError) throw questionsError

        setQuestions(questionsData || [])
        setLoading(false)
      } catch (error) {
        console.error("Error fetching test:", error)
        toast({
          title: "Error",
          description: "Failed to load test. Please try again.",
          variant: "destructive",
        })
        router.push("/dashboard/admin/tests")
      }
    }

    fetchTest()
  }, [params.id, router, supabase, toast])

  const handleUpdateTest = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!title || !description || !date || !duration) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const { error } = await supabase
        .from("tests")
        .update({
          title,
          description,
          scheduled_date: date.toISOString(),
          duration: Number.parseInt(duration),
          is_weekend: isWeekend,
          is_published: isPublished,
        })
        .eq("id", params.id)

      if (error) throw error

      toast({
        title: "Test updated",
        description: "Your test has been updated successfully.",
      })
    } catch (error) {
      console.error("Error updating test:", error)
      toast({
        title: "Error",
        description: "Failed to update test. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleAddQuestion = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newQuestion || options.some((opt) => !opt) || !correctAnswer) {
      toast({
        title: "Missing fields",
        description: "Please fill in all question fields and options.",
        variant: "destructive",
      })
      return
    }

    if (!options.includes(correctAnswer)) {
      toast({
        title: "Invalid correct answer",
        description: "The correct answer must be one of the options.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const { data, error } = await supabase
        .from("questions")
        .insert({
          test_id: params.id,
          question: newQuestion,
          options: options,
          correct_answer: correctAnswer,
          subject: subject || null,
          order: questions.length + 1,
        })
        .select()

      if (error) throw error

      if (data) {
        setQuestions([...questions, data[0]])

        // Reset form
        setNewQuestion("")
        setOptions(["", "", "", ""])
        setCorrectAnswer("")
        setSubject("")

        toast({
          title: "Question added",
          description: "Your question has been added successfully.",
        })
      }
    } catch (error) {
      console.error("Error adding question:", error)
      toast({
        title: "Error",
        description: "Failed to add question. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteQuestion = async (questionId: string) => {
    try {
      const { error } = await supabase.from("questions").delete().eq("id", questionId)

      if (error) throw error

      setQuestions(questions.filter((q) => q.id !== questionId))

      toast({
        title: "Question deleted",
        description: "The question has been deleted successfully.",
      })
    } catch (error) {
      console.error("Error deleting question:", error)
      toast({
        title: "Error",
        description: "Failed to delete question. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleOptionChange = (index: number, value: string) => {
    const newOptions = [...options]
    newOptions[index] = value
    setOptions(newOptions)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading test...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Edit Test</h2>
        <p className="text-muted-foreground">Update test details and manage questions</p>
      </div>

      <Tabs defaultValue="details" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="details">Test Details</TabsTrigger>
          <TabsTrigger value="questions">Questions ({questions.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="details">
          <form onSubmit={handleUpdateTest}>
            <Card>
              <CardHeader>
                <CardTitle>Test Details</CardTitle>
                <CardDescription>Update the basic information for your test</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Test Title</Label>
                  <Input
                    id="title"
                    placeholder="e.g., Daily Math Test - Week 1"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Brief description of the test content and objectives"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    required
                  />
                </div>

                <div className="grid gap-6 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Scheduled Date</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {date ? formatDate(date) : "Select date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="duration">Duration (minutes)</Label>
                    <Input
                      id="duration"
                      type="number"
                      min="5"
                      max="180"
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="weekend-test" className="flex flex-col gap-1">
                      <span>Weekend Test</span>
                      <span className="font-normal text-sm text-muted-foreground">
                        Mark this as a weekend test (more comprehensive)
                      </span>
                    </Label>
                    <Switch id="weekend-test" checked={isWeekend} onCheckedChange={setIsWeekend} />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="publish" className="flex flex-col gap-1">
                      <span>Publish Test</span>
                      <span className="font-normal text-sm text-muted-foreground">
                        Make this test available to students
                      </span>
                    </Label>
                    <Switch id="publish" checked={isPublished} onCheckedChange={setIsPublished} />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button type="button" variant="outline" onClick={() => router.push("/dashboard/admin/tests")}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    "Save Changes"
                  )}
                </Button>
              </CardFooter>
            </Card>
          </form>
        </TabsContent>

        <TabsContent value="questions" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Add New Question</CardTitle>
              <CardDescription>Create a new multiple-choice question for this test</CardDescription>
            </CardHeader>
            <form onSubmit={handleAddQuestion}>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="question">Question</Label>
                  <Textarea
                    id="question"
                    placeholder="Enter your question here"
                    value={newQuestion}
                    onChange={(e) => setNewQuestion(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subject">Subject (Optional)</Label>
                  <Input
                    id="subject"
                    placeholder="e.g., Math, Science, English"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                  />
                </div>

                <div className="space-y-4">
                  <Label>Answer Options</Label>
                  {options.map((option, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        placeholder={`Option ${index + 1}`}
                        value={option}
                        onChange={(e) => handleOptionChange(index, e.target.value)}
                        required
                      />
                    </div>
                  ))}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="correct-answer">Correct Answer</Label>
                  <Select value={correctAnswer} onValueChange={setCorrectAnswer}>
                    <SelectTrigger id="correct-answer">
                      <SelectValue placeholder="Select the correct answer" />
                    </SelectTrigger>
                    <SelectContent>
                      {options.map(
                        (option, index) =>
                          option && (
                            <SelectItem key={index} value={option}>
                              {option}
                            </SelectItem>
                          ),
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
              <CardFooter>
                <Button type="submit" className="ml-auto gap-2" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Adding...
                    </>
                  ) : (
                    <>
                      <Plus className="h-4 w-4" /> Add Question
                    </>
                  )}
                </Button>
              </CardFooter>
            </form>
          </Card>

          <div className="space-y-4">
            <h3 className="text-lg font-medium">Existing Questions ({questions.length})</h3>

            {questions.map((question, index) => (
              <Card key={question.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-base">
                      {index + 1}. {question.question}
                    </CardTitle>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteQuestion(question.id)}>
                      <Trash className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                  {question.subject && <CardDescription>Subject: {question.subject}</CardDescription>}
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="text-sm font-medium">Options:</div>
                    <ul className="space-y-1 pl-5 list-disc">
                      {question.options.map((option: string, optIndex: number) => (
                        <li
                          key={optIndex}
                          className={option === question.correct_answer ? "font-medium text-primary" : ""}
                        >
                          {option} {option === question.correct_answer && "(Correct)"}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}

            {questions.length === 0 && (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">No questions added yet. Add your first question above.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
