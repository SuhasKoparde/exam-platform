import Link from "next/link"
import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { formatDate } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, Edit, Plus, Trash } from "lucide-react"

export default async function AdminTestsPage() {
  const supabase = createClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    redirect("/login")
  }

  // Check if user is admin
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", session.user.id).single()

  if (profile?.role !== "admin") {
    redirect("/dashboard")
  }

  // Get all tests
  const { data: tests } = await supabase
    .from("tests")
    .select("*, questions(count)")
    .order("scheduled_date", { ascending: false })

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Manage Tests</h2>
          <p className="text-muted-foreground">Create, edit, and manage tests for students</p>
        </div>
        <Link href="/dashboard/admin/tests/new">
          <Button className="gap-2">
            <Plus className="h-4 w-4" /> Create New Test
          </Button>
        </Link>
      </div>

      <div className="grid gap-6">
        {tests?.map((test) => (
          <Card key={test.id}>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>{test.title}</CardTitle>
                  <CardDescription>{test.description}</CardDescription>
                </div>
                <Badge variant={test.is_published ? "default" : "outline"}>
                  {test.is_published ? "Published" : "Draft"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pb-3">
              <div className="flex flex-wrap gap-4 text-sm">
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>{formatDate(new Date(test.scheduled_date))}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>{test.duration} min</span>
                </div>
                <div className="flex items-center gap-1">
                  <Badge variant="secondary">{test.is_weekend ? "Weekend Test" : "Daily Test"}</Badge>
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-muted-foreground">{test.questions.count} questions</span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end gap-2">
              <Link href={`/dashboard/admin/tests/${test.id}`}>
                <Button variant="outline" size="sm" className="gap-1">
                  <Edit className="h-4 w-4" /> Edit
                </Button>
              </Link>
              <form action={`/dashboard/admin/tests/${test.id}/delete`}>
                <Button variant="destructive" size="sm" className="gap-1">
                  <Trash className="h-4 w-4" /> Delete
                </Button>
              </form>
            </CardFooter>
          </Card>
        ))}

        {(!tests || tests.length === 0) && (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <div className="text-center space-y-3">
                <h3 className="text-lg font-medium">No tests found</h3>
                <p className="text-muted-foreground">Get started by creating your first test</p>
                <Link href="/dashboard/admin/tests/new">
                  <Button className="gap-2 mt-2">
                    <Plus className="h-4 w-4" /> Create New Test
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
