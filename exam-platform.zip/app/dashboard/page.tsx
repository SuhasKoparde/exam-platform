import { createClient } from "@/lib/supabase/server"
import { formatDate } from "@/lib/utils"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight, Calendar, CheckCircle, Clock, Trophy, TrendingUp, BarChart3 } from "lucide-react"
import Link from "next/link"

export default async function DashboardPage() {
  const supabase = createClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    return null
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", session.user.id).single()

  const { data: tests } = await supabase.from("tests").select("*").order("created_at", { ascending: false }).limit(5)

  const { data: results } = await supabase
    .from("test_results")
    .select("*")
    .eq("user_id", session.user.id)
    .order("created_at", { ascending: false })
    .limit(10)

  const isAdmin = profile?.role === "admin"

  // Calculate average score
  const averageScore =
    results && results.length > 0
      ? Math.round(results.reduce((sum, result) => sum + result.score, 0) / results.length)
      : 0

  // Mock data for performance visualization
  const performanceData = [
    { day: "Mon", score: 85, height: "85%" },
    { day: "Tue", score: 72, height: "72%" },
    { day: "Wed", score: 90, height: "90%" },
    { day: "Thu", score: 78, height: "78%" },
    { day: "Fri", score: 82, height: "82%" },
    { day: "Sat", score: 95, height: "95%" },
    { day: "Sun", score: 88, height: "88%" },
  ]

  const subjectPerformance = [
    { subject: "Math", score: 85, width: "85%" },
    { subject: "Science", score: 72, width: "72%" },
    { subject: "English", score: 90, width: "90%" },
    { subject: "History", score: 78, width: "78%" },
    { subject: "Geography", score: 82, width: "82%" },
  ]

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
          <p className="text-muted-foreground">Welcome back, {profile?.name || "User"}!</p>
        </div>
        {isAdmin ? (
          <Link href="/dashboard/admin/tests/new">
            <Button>Create New Test</Button>
          </Link>
        ) : (
          <Link href="/dashboard/tests">
            <Button>Take Today's Test</Button>
          </Link>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tests Completed</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{results?.length || 0}</div>
            <p className="text-xs text-muted-foreground">+2 from last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Score</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{averageScore}%</div>
            <p className="text-xs text-muted-foreground">+5% from last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rank</CardTitle>
            <Trophy className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">+3 positions from last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Next Test</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Today</div>
            <p className="text-xs text-muted-foreground">Daily test available now</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="subjects">Subjects</TabsTrigger>
        </TabsList>
        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Weekly Performance
              </CardTitle>
              <CardDescription>Your test scores over the past week</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-end justify-between h-64 gap-2">
                  {performanceData.map((day) => (
                    <div key={day.day} className="flex flex-col items-center gap-2 flex-1">
                      <div className="text-sm font-medium">{day.score}%</div>
                      <div
                        className="w-full bg-primary rounded-t-md min-h-[20px] flex items-end justify-center"
                        style={{ height: day.height }}
                      >
                        <span className="text-xs text-primary-foreground pb-1">{day.score}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">{day.day}</div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="subjects" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Subject Performance
              </CardTitle>
              <CardDescription>Your performance across different subjects</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {subjectPerformance.map((subject) => (
                  <div key={subject.subject} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-medium">{subject.subject}</span>
                      <span className="text-muted-foreground">{subject.score}%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div
                        className="bg-primary h-2 rounded-full transition-all duration-300"
                        style={{ width: subject.width }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="col-span-1">
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle>Upcoming Tests</CardTitle>
            <Link href="/dashboard/tests">
              <Button variant="ghost" className="gap-1">
                View All <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {tests?.map((test) => (
                <div key={test.id} className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <Calendar className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium leading-none">{test.title}</p>
                    <p className="text-sm text-muted-foreground">{formatDate(new Date(test.scheduled_date))}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">{test.duration} min</span>
                  </div>
                </div>
              ))}
              {(!tests || tests.length === 0) && (
                <p className="text-sm text-muted-foreground">No upcoming tests found.</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle>Recent Results</CardTitle>
            <Link href="/dashboard/results">
              <Button variant="ghost" className="gap-1">
                View All <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {results?.map((result) => (
                <div key={result.id} className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <div className="text-sm font-medium text-primary">{result.score}%</div>
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium leading-none">{result.test_title}</p>
                    <p className="text-sm text-muted-foreground">{formatDate(new Date(result.created_at))}</p>
                  </div>
                </div>
              ))}
              {(!results || results.length === 0) && (
                <p className="text-sm text-muted-foreground">No recent results found.</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
