import Link from "next/link"
import { createClient } from "@/lib/supabase/server"
import { formatDate } from "@/lib/utils"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock } from "lucide-react"

export default async function TestsPage() {
  const supabase = createClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    return null
  }

  const today = new Date().toISOString().split("T")[0]

  // Get all available tests
  const { data: tests } = await supabase
    .from("tests")
    .select("*")
    .lte("scheduled_date", today)
    .order("scheduled_date", { ascending: false })

  // Get user's completed tests
  const { data: completedTests } = await supabase.from("test_results").select("test_id").eq("user_id", session.user.id)

  const completedTestIds = completedTests?.map((test) => test.test_id) || []

  // Separate tests into daily and weekend tests
  const dailyTests = tests?.filter((test) => !test.is_weekend) || []
  const weekendTests = tests?.filter((test) => test.is_weekend) || []

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Available Tests</h2>
        <p className="text-muted-foreground">Take daily and weekend tests to improve your skills</p>
      </div>

      <div className="space-y-8">
        <div>
          <h3 className="text-xl font-semibold mb-4">Daily Tests</h3>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {dailyTests.map((test) => {
              const isCompleted = completedTestIds.includes(test.id)
              return (
                <Card key={test.id} className={isCompleted ? "border-muted bg-muted/50" : ""}>
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle>{test.title}</CardTitle>
                      {isCompleted ? <Badge variant="outline">Completed</Badge> : <Badge>Available</Badge>}
                    </div>
                    <CardDescription>{test.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span>{formatDate(new Date(test.scheduled_date))}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{test.duration} min</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    {isCompleted ? (
                      <Link href={`/dashboard/tests/results/${test.id}`} className="w-full">
                        <Button variant="outline" className="w-full">
                          View Results
                        </Button>
                      </Link>
                    ) : (
                      <Link href={`/dashboard/tests/${test.id}`} className="w-full">
                        <Button className="w-full">Start Test</Button>
                      </Link>
                    )}
                  </CardFooter>
                </Card>
              )
            })}
            {dailyTests.length === 0 && (
              <Card className="col-span-full">
                <CardContent className="pt-6 text-center">
                  <p className="text-muted-foreground">No daily tests available at the moment.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        <div>
          <h3 className="text-xl font-semibold mb-4">Weekend Tests</h3>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {weekendTests.map((test) => {
              const isCompleted = completedTestIds.includes(test.id)
              return (
                <Card key={test.id} className={isCompleted ? "border-muted bg-muted/50" : ""}>
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle>{test.title}</CardTitle>
                      {isCompleted ? <Badge variant="outline">Completed</Badge> : <Badge>Available</Badge>}
                    </div>
                    <CardDescription>{test.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-3">
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span>{formatDate(new Date(test.scheduled_date))}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span>{test.duration} min</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    {isCompleted ? (
                      <Link href={`/dashboard/tests/results/${test.id}`} className="w-full">
                        <Button variant="outline" className="w-full">
                          View Results
                        </Button>
                      </Link>
                    ) : (
                      <Link href={`/dashboard/tests/${test.id}`} className="w-full">
                        <Button className="w-full">Start Test</Button>
                      </Link>
                    )}
                  </CardFooter>
                </Card>
              )
            })}
            {weekendTests.length === 0 && (
              <Card className="col-span-full">
                <CardContent className="pt-6 text-center">
                  <p className="text-muted-foreground">No weekend tests available at the moment.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
