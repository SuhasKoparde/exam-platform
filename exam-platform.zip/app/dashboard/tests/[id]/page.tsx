"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { useAuth } from "@/components/auth-provider"
import { calculateScore } from "@/lib/utils"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/components/ui/use-toast"
import { AlertCircle, Clock } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function TestPage({ params }: { params: { id: string } }) {
  const [test, setTest] = useState<any>(null)
  const [questions, setQuestions] = useState<any[]>([])
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [timeLeft, setTimeLeft] = useState<number | null>(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const router = useRouter()
  const { user } = useAuth()
  const supabase = createClient()
  const { toast } = useToast()

  useEffect(() => {
    const fetchTest = async () => {
      try {
        // Check if user has already taken this test
        if (user) {
          const { data: existingResult } = await supabase
            .from("test_results")
            .select("*")
            .eq("test_id", params.id)
            .eq("user_id", user.id)
            .single()

          if (existingResult) {
            // User has already taken this test, redirect to results
            router.push(`/dashboard/tests/results/${params.id}`)
            return
          }
        }

        // Fetch test details
        const { data: testData, error: testError } = await supabase
          .from("tests")
          .select("*")
          .eq("id", params.id)
          .single()

        if (testError) throw testError
        setTest(testData)

        // Fetch questions
        const { data: questionsData, error: questionsError } = await supabase
          .from("questions")
          .select("*")
          .eq("test_id", params.id)
          .order("order", { ascending: true })

        if (questionsError) throw questionsError
        setQuestions(questionsData)

        // Initialize timer
        if (testData.duration) {
          setTimeLeft(testData.duration * 60) // Convert minutes to seconds
        }

        setLoading(false)
      } catch (error) {
        console.error("Error fetching test:", error)
        toast({
          title: "Error",
          description: "Failed to load test. Please try again.",
          variant: "destructive",
        })
        router.push("/dashboard/tests")
      }
    }

    fetchTest()
  }, [params.id, router, supabase, toast, user])

  // Timer effect
  useEffect(() => {
    if (timeLeft === null || timeLeft <= 0 || loading) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev === null || prev <= 1) {
          clearInterval(timer)
          handleSubmit()
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [timeLeft, loading])

  const handleAnswerChange = (questionId: string, answer: string) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: answer,
    }))
  }

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1)
    }
  }

  const handleSubmit = async () => {
    if (!user) return

    setSubmitting(true)

    try {
      // Get correct answers
      const { data: correctAnswersData } = await supabase
        .from("questions")
        .select("id, correct_answer")
        .eq("test_id", params.id)

      const correctAnswers =
        correctAnswersData?.reduce(
          (acc, q) => {
            acc[q.id] = q.correct_answer
            return acc
          },
          {} as Record<string, string>,
        ) || {}

      // Calculate score
      const result = calculateScore(answers, correctAnswers)

      // Save test result
      await supabase.from("test_results").insert({
        user_id: user.id,
        test_id: params.id,
        test_title: test.title,
        score: result.percentage,
        answers: answers,
        total_questions: result.total,
        correct_answers: result.score,
      })

      // Redirect to results page
      router.push(`/dashboard/tests/results/${params.id}`)
    } catch (error) {
      console.error("Error submitting test:", error)
      toast({
        title: "Error",
        description: "Failed to submit test. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds < 10 ? "0" : ""}${remainingSeconds}`
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading test...</p>
        </div>
      </div>
    )
  }

  const currentQuestion = questions[currentQuestionIndex]
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100
  const answeredCount = Object.keys(answers).length

  return (
    <div className="space-y-8 max-w-3xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">{test.title}</h2>
          <p className="text-muted-foreground">{test.description}</p>
        </div>
        {timeLeft !== null && (
          <div className="flex items-center gap-2 text-lg font-semibold">
            <Clock className="h-5 w-5" />
            <span>{formatTime(timeLeft)}</span>
          </div>
        )}
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span>
            Question {currentQuestionIndex + 1} of {questions.length}
          </span>
          <span>{answeredCount} answered</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {answeredCount < questions.length && timeLeft && timeLeft < 60 && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Time is running out!</AlertTitle>
          <AlertDescription>You have less than a minute left. Please finish your test.</AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Question {currentQuestionIndex + 1}</CardTitle>
          <CardDescription>
            {currentQuestion?.subject && (
              <span className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2">
                {currentQuestion.subject}
              </span>
            )}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="text-lg font-medium">{currentQuestion?.question}</div>

            <RadioGroup
              value={answers[currentQuestion?.id] || ""}
              onValueChange={(value) => handleAnswerChange(currentQuestion?.id, value)}
            >
              <div className="space-y-3">
                {currentQuestion?.options.map((option: string, index: number) => (
                  <div
                    key={index}
                    className="flex items-center space-x-2 border rounded-md p-3 hover:bg-muted/50 transition-colors"
                  >
                    <RadioGroupItem value={option} id={`option-${index}`} />
                    <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                      {option}
                    </Label>
                  </div>
                ))}
              </div>
            </RadioGroup>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={handlePrevious} disabled={currentQuestionIndex === 0}>
            Previous
          </Button>

          {currentQuestionIndex < questions.length - 1 ? (
            <Button onClick={handleNext}>Next</Button>
          ) : (
            <Button onClick={handleSubmit} disabled={submitting || answeredCount < questions.length}>
              {submitting ? "Submitting..." : "Submit Test"}
            </Button>
          )}
        </CardFooter>
      </Card>

      {currentQuestionIndex === questions.length - 1 && answeredCount < questions.length && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>You haven't answered all questions</AlertTitle>
          <AlertDescription>
            You've answered {answeredCount} out of {questions.length} questions. Use the Previous button to go back and
            complete all questions before submitting.
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}
