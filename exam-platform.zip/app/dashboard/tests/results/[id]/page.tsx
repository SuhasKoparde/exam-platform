import { createClient } from "@/lib/supabase/server"
import { formatDate } from "@/lib/utils"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle, PieChart } from "lucide-react"
import Link from "next/link"

export default async function TestResultPage({ params }: { params: { id: string } }) {
  const supabase = createClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    return null
  }

  // Get test result
  const { data: result } = await supabase
    .from("test_results")
    .select("*")
    .eq("test_id", params.id)
    .eq("user_id", session.user.id)
    .single()

  if (!result) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-4">
        <h2 className="text-2xl font-bold">No results found</h2>
        <p className="text-muted-foreground">You haven't taken this test yet.</p>
        <Link href="/dashboard/tests">
          <Button>Go to Tests</Button>
        </Link>
      </div>
    )
  }

  // Get test details
  const { data: test } = await supabase.from("tests").select("*").eq("id", params.id).single()

  // Get questions with correct answers
  const { data: questions } = await supabase
    .from("questions")
    .select("*")
    .eq("test_id", params.id)
    .order("order", { ascending: true })

  // Calculate percentages
  const correctPercentage = Math.round((result.correct_answers / result.total_questions) * 100)
  const incorrectPercentage = 100 - correctPercentage

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Test Results</h2>
        <p className="text-muted-foreground">
          {test?.title} - Completed on {formatDate(new Date(result.created_at))}
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-5 w-5" />
              Score Summary
            </CardTitle>
            <CardDescription>Your performance on this test</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <div className="relative flex items-center justify-center mb-6">
              <div className="text-4xl font-bold">{result.score}%</div>
            </div>

            {/* Simple progress visualization */}
            <div className="w-full space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-green-600">Correct</span>
                <span className="text-sm font-medium">{correctPercentage}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-3">
                <div
                  className="bg-green-500 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${correctPercentage}%` }}
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-red-600">Incorrect</span>
                <span className="text-sm font-medium">{incorrectPercentage}%</span>
              </div>
              <div className="w-full bg-muted rounded-full h-3">
                <div
                  className="bg-red-500 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${incorrectPercentage}%` }}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 w-full mt-6">
              <div className="flex flex-col items-center p-3 bg-muted rounded-md">
                <div className="text-sm font-medium text-muted-foreground">Correct</div>
                <div className="text-2xl font-bold text-green-600">{result.correct_answers}</div>
              </div>
              <div className="flex flex-col items-center p-3 bg-muted rounded-md">
                <div className="text-sm font-medium text-muted-foreground">Total</div>
                <div className="text-2xl font-bold">{result.total_questions}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Performance Analysis</CardTitle>
            <CardDescription>Detailed breakdown of your answers</CardDescription>
          </CardHeader>
          <CardContent className="h-[400px] overflow-y-auto">
            <div className="space-y-4">
              {questions?.map((question, index) => {
                const userAnswer = result.answers[question.id]
                const isCorrect = userAnswer === question.correct_answer

                return (
                  <div key={question.id} className="border rounded-md p-4">
                    <div className="flex items-start gap-3">
                      <div className={`flex-shrink-0 ${isCorrect ? "text-green-600" : "text-red-600"}`}>
                        {isCorrect ? <CheckCircle className="h-5 w-5" /> : <XCircle className="h-5 w-5" />}
                      </div>
                      <div className="space-y-2 flex-1">
                        <div className="font-medium">
                          {index + 1}. {question.question}
                        </div>
                        <div className="text-sm">
                          <span className="font-medium">Your answer:</span> {userAnswer || "Not answered"}
                        </div>
                        {!isCorrect && (
                          <div className="text-sm text-green-600 font-medium">
                            Correct answer: {question.correct_answer}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-center gap-4">
        <Link href="/dashboard/tests">
          <Button variant="outline">Back to Tests</Button>
        </Link>
        <Link href="/dashboard">
          <Button>Go to Dashboard</Button>
        </Link>
      </div>
    </div>
  )
}
