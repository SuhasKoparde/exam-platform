-- Create tables for the exam platform

-- Profiles table to store user information
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin', 'student')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tests table to store test information
CREATE TABLE tests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  description TEXT,
  scheduled_date DATE NOT NULL,
  duration INTEGER NOT NULL, -- in minutes
  is_weekend BOOLEAN DEFAULT FALSE,
  is_published BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Questions table to store test questions
CREATE TABLE questions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  test_id UUID NOT NULL REFERENCES tests ON DELETE CASCADE,
  question TEXT NOT NULL,
  options TEXT[] NOT NULL,
  correct_answer TEXT NOT NULL,
  subject TEXT,
  order INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Test results table to store student test results
CREATE TABLE test_results (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles ON DELETE CASCADE,
  test_id UUID NOT NULL REFERENCES tests ON DELETE CASCADE,
  test_title TEXT NOT NULL,
  score INTEGER NOT NULL, -- percentage score
  answers JSONB NOT NULL, -- user's answers
  total_questions INTEGER NOT NULL,
  correct_answers INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, test_id)
);

-- Function to get weekly leaderboard
CREATE OR REPLACE FUNCTION get_weekly_leaderboard()
RETURNS TABLE (
  user_id UUID,
  name TEXT,
  average_score NUMERIC,
  tests_taken INTEGER
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    p.id AS user_id,
    p.name,
    ROUND(AVG(tr.score), 1) AS average_score,
    COUNT(tr.id) AS tests_taken
  FROM
    profiles p
    JOIN test_results tr ON p.id = tr.user_id
  WHERE
    tr.created_at >= NOW() - INTERVAL '7 days'
    AND p.role = 'student'
  GROUP BY
    p.id, p.name
  ORDER BY
    average_score DESC;
END;
$$ LANGUAGE plpgsql;

-- Function to get monthly leaderboard
CREATE OR REPLACE FUNCTION get_monthly_leaderboard()
RETURNS TABLE (
  user_id UUID,
  name TEXT,
  average_score NUMERIC,
  tests_taken INTEGER
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    p.id AS user_id,
    p.name,
    ROUND(AVG(tr.score), 1) AS average_score,
    COUNT(tr.id) AS tests_taken
  FROM
    profiles p
    JOIN test_results tr ON p.id = tr.user_id
  WHERE
    tr.created_at >= NOW() - INTERVAL '30 days'
    AND p.role = 'student'
  GROUP BY
    p.id, p.name
  ORDER BY
    average_score DESC;
END;
$$ LANGUAGE plpgsql;

-- Function to get all-time leaderboard
CREATE OR REPLACE FUNCTION get_all_time_leaderboard()
RETURNS TABLE (
  user_id UUID,
  name TEXT,
  average_score NUMERIC,
  tests_taken INTEGER
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    p.id AS user_id,
    p.name,
    ROUND(AVG(tr.score), 1) AS average_score,
    COUNT(tr.id) AS tests_taken
  FROM
    profiles p
    JOIN test_results tr ON p.id = tr.user_id
  WHERE
    p.role = 'student'
  GROUP BY
    p.id, p.name
  ORDER BY
    average_score DESC;
END;
$$ LANGUAGE plpgsql;

-- Create RLS policies

-- Profiles table policies
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles"
  ON profiles FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Tests table policies
ALTER TABLE tests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Published tests are viewable by all users"
  ON tests FOR SELECT
  USING (is_published = TRUE);

CREATE POLICY "Admins can manage all tests"
  ON tests FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Questions table policies
ALTER TABLE questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Questions are viewable by all users"
  ON questions FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM tests
      WHERE id = test_id AND is_published = TRUE
    )
  );

CREATE POLICY "Admins can manage all questions"
  ON questions FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );

-- Test results table policies
ALTER TABLE test_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own results"
  ON test_results FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own results"
  ON test_results FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all results"
  ON test_results FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role = 'admin'
    )
  );
